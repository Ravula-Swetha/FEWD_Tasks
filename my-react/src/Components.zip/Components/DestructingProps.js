function DestructindProps({name, place}){
    return(
        <>
        <h1>Destructing: Props</h1>
        <h3>Hello {name} </h3>
        <h3>Welcome to {place} </h3>
        <hr></hr>
        </>
    )
}

export default DestructindProps;